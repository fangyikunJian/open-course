---
name: teaching-viz
description: Plan and build visual explanations of mathematical, statistical and machine-learning ideas — Manim animations, static figures, and the explanation scripts behind them — using evidence-based instructional-design rules instead of defaulting to animation. Use this skill whenever the user wants to explain, teach, illustrate, animate, or visualise a concept, derivation, proof, algorithm, or formula; whenever they mention Manim, 3Blue1Brown-style videos, explainer videos, lecture visuals, tutorial figures, teaching slides, or course/tutoring material; and whenever they ask "how do I show X" or "how do I explain X" — even if they never say the words "animation" or "visualisation". Use it for a single diagram as readily as for a full video.
---

# Teaching Visualisation

## Core stance

The explanation is the product. The medium (animation, figure, interactive) is a
delivery decision made *after* the explanation exists. Visuals almost never fail
because the code was bad; they fail because nobody decided what one idea the
viewer should walk away with, or because animation was chosen when a labelled
static figure would have taught more.

The empirical picture is deflating and should be treated as the baseline
assumption: across meta-analyses, animation beats static graphics by only a
small-to-medium margin (d ≈ 0.37; g ≈ 0.23), and the advantage concentrates in
*representational* animation of things that genuinely change over time. Motion
that decorates rather than represents buys nothing and costs working memory.
See `references/evidence.md` for the full basis of every rule below.

Three non-negotiables:

1. **Choose the medium at Step 2, before writing any code.** Animation must be
   earned by the congruence test, not assumed.
2. **Every deliverable carries one aha and one generative prompt.** Passive
   watching is the weakest learning mode there is.
3. **Never ship a frame you have not looked at.** Rendering is not checking.
   Layout collisions are the single most common failure of generated animation.

## Workflow

Follow all five steps in order. Do not skip to Step 4 because the user asked
for "a Manim animation of X" — they are describing a medium, not a brief.
If the user's request is already precise about audience and message, Step 1
can be one short paragraph, but it still gets written.

### Step 1 — Write the brief (always, before anything else)

Produce these six lines and show them to the user. They are cheap to fix now
and expensive to fix after rendering.

| Field | What goes in it |
|---|---|
| Audience | Who, and specifically what they already know. Prior knowledge changes the right design more than any other variable. |
| Prior representation | What notation/picture they have already met for this topic. Build on it; do not invent a competing one. |
| Message | One sentence: what they should be able to do or see afterwards. If it needs "and", split into two deliverables. |
| Motivation | One sentence answering "why should I care", deliverable in the first 30 seconds. |
| Misconception | The wrong mental model this is fighting, stated sympathetically. Not optional: explicitly refuting the viewer's wrong model is the largest single effect in the evidence base, roughly twice the size of animating at all. If you cannot name one, look harder before concluding there isn't one. |
| The aha | The single moment of insight. One per deliverable. |

Then state the assumed prior knowledge *in the deliverable itself*. Novices and
experts need opposite amounts of scaffolding, so the artefact should say who it
is for.

### Step 2 — The medium gate

Run these tests in order and stop at the first that fires.

**First, check whether the medium is already decided.** It is decided if the
user asked for an animation, if the piece is an episode in an existing animated
series, if the brief or the project is *about* making animations, or if the
output has to match material that already exists. In that case the gate is not
a decision and must not be run as a veto. Say in at most one sentence what the
questions below would have flagged, then go straight to
**"Animation with the medium locked"** and spend the effort on making the
animation good. Talking someone out of the medium they came for is not help.

Only when the medium is genuinely open, run these four questions in order.

**Q1 — Congruence.** Does the content contain change over time, a process, a
causal chain, or a construction order?
- **No** → static figure. `references/static-figures.md`. Most algebraic
  identities, most structural relationships, and most "which of these is bigger"
  arguments land here.
- **Yes** → Q2.

**Q2 — Simultaneity.** Could everything the viewer needs to compare be shown
legibly *at the same time*, on one page — as a path, a strip, or stacked lines?
- **Yes** → static wins by default, and animation now has to earn its place by
  adding something the still cannot give. Q1 is easy to pass: a parameter sweep,
  a derivation, and a proof all contain order. This is the question that
  actually decides most cases, because a still keeps every state permanent while
  an animation takes that away.
- **No** → Q3.

**Q3 — Apprehension.** Can a first-time viewer follow the change at the speed
it happens?
- **No** → decompose into discrete beats. Continuous processes are usually
  understood as a series of discrete states anyway, so the strip or the
  beat-by-beat build may be the *congruent* form, not a downgrade.
- **Yes** → Q4.

**Q4 — Manipulation.** Would the learner want to move a parameter themselves?
- **Yes** → an interactive beats a video of you moving the slider. This version
  does not build interactives: say so, and deliver the parameter sweep with a
  summary frame (see below) as the closest substitute.
- **No** → animate.

Record which question decided it, in one line.

### Animation with the medium locked

When animation is given rather than chosen, the four questions stop being
vetoes and become the design spec. Run them silently anyway: each one that
*would* have failed names a specific thing this animation has to do in order to
survive the objection behind it. This is where most of the value of the skill
sits for animation work.

| Would have failed | So the animation must |
|---|---|
| **Congruence** — the idea does not inherently move | Use motion for *construction order and attention routing*, not to fake dynamics. The honest form is the progressive build: animate the assembly of a figure that ends as a still. Do not invent movement the mathematics does not have. |
| **Simultaneity** — the whole thing would fit on one page | Build cumulatively and never erase. The final frame should be the figure you would have drawn anyway, and should stand alone. Animation earns its keep by controlling the *order* in which attention arrives, which a still cannot do. Export that last frame as a figure too. |
| **Apprehension** — too fast or too dense to follow | Discrete beats with real holds between them. One change per beat, and a wait after every reveal. |
| **Manipulation** — the learner wants a slider | Parameter sweep: hold at three named values rather than sliding continuously past everything, leave a visible trace of where the sweep has been, and end on a summary frame showing the key values together. |

Three archetypes cover nearly all mathematical animation. Name which one you
are building before writing code; mixing them inside one segment is a common
way to lose the viewer.

1. **Progressive build** — a still figure assembled one element at a time.
   For structural arguments. Requirement: nothing ever leaves; the last frame
   is a complete, self-sufficient figure.
2. **Parameter sweep** — one quantity varies, everything else holds.
   For λ, for a hyperparameter, for an angle. Requirement: a trace, named
   holds, and a summary frame.
3. **Transformation** — one object becomes another, and the motion *is* the
   argument. For change of basis, for a substitution, for a proof step.
   Requirement: both endpoints readable during the motion, or show them side
   by side and animate the correspondence instead.

Details and code patterns for all three: `references/manim.md`.

### Step 3 — Segment and storyboard

**If the deliverable is a video explaining one knowledge point, read
`references/explainer-arc.md` now** and fill in its per-episode spec sheet
instead of improvising the structure. It gives the six-beat arc, the time
budget, and the series-consistency rules. The rest of this step still applies.

**Segment.** One idea per segment. If the deliverable is a video, each segment
is a natural stopping point and the whole thing stays under six minutes;
longer topics become several short pieces, not one long one. Short segments are
the single most reliable fix for the working-memory cost of moving pictures.

**Order.** Structure the explanation concrete → intermediate → abstract, and
make the fading explicit: keep the concrete instance visible while the general
symbol appears, so the two are seen as the same thing. Jumping straight to the
general symbol is the default failure of mathematical exposition.

**Pre-train.** Name and show every object before showing what it does. Never
introduce a new symbol and a new process in the same beat.

**Storyboard.** For each segment write a three-column table before touching code:

| On screen | Said / captioned | Stays or goes |
|---|---|---|

Rules for that table:
- Anything that must be compared later goes in "stays".
- Words go next to the thing they label, not in a legend elsewhere.
- Narration and the visual it describes happen at the same time, not in sequence.
- Do not put the narration on screen as text as well. Duplicating spoken words
  as on-screen text hurts. Short labels are not duplication; sentences are.
- Cut anything that is interesting but not on the message. Interesting-but-extra
  material measurably reduces learning.

**Plan the generative prompt.** Decide now where the learner does something:
a predict-then-reveal pause, a "what happens if this term goes to zero", a
question posed before the answer is shown. One per deliverable, minimum.

### Step 4 — Build

- Manim animation → read `references/manim.md`.
- Static figure → read `references/static-figures.md`.
- Both files assume the brief and storyboard from Steps 1–3 already exist.

Start from `assets/scene_template.py` for Manim work; it encodes the layout
budget, the permanent-region convention, and the colour rules.

### Step 5 — Self-check before delivering

Render, then **look at the frames**. Use `scripts/frame_check.py` to dump
frames from the rendered video and view them. For static figures, view the
image. This step is not optional and not delegable to the render succeeding:
generated animation fails on spatial layout far more often than on syntax.

Then walk the rubric. Fix anything that fails; do not report the deliverable
as done with a known failure in it.

## Review rubric

**Explanation quality**
- [ ] The wrong model is named early and refuted explicitly later. An
      explanation that never collides with what the viewer already believes
      feels clear and changes little.
- [ ] Motivation lands in the first 30 seconds / first look.
- [ ] Jargon is explained; the assumed background is stated.
- [ ] There is one clear aha, and it is the thing the visual emphasises.
- [ ] It offers something the reader could not get from the first search result.
- [ ] There is something memorable — an image, a reframing, a surprise.

**Cognitive load**
- [ ] Nothing on screen is decorative.
- [ ] Every referent needed for a comparison is still visible when the
      comparison is asked for.
- [ ] Labels sit next to their objects.
- [ ] Narration is not duplicated as on-screen sentences.
- [ ] Each segment is one idea; video segments are under six minutes.

**Attention**
- [ ] Key elements are cued when they matter, and cued *dynamically* inside
      animation — a static colour change is too weak to win against motion.
- [ ] Cues point at what matters, not at what happens to be moving.

**Representation linking**
- [ ] When two representations are shown (equation and picture, geometry and
      algebra), they are on screen together and the correspondence is made
      explicit by shared colour, shared labels, or an animated mapping.
- [ ] The learner is not left to infer the link. Most of them will not.

**Legibility**
- [ ] Every frame is collision-free; nothing overlaps that should not.
- [ ] Text is readable at the smallest intended viewing size.
- [ ] Colour is perceptually uniform and colour-vision-deficiency safe; meaning
      is never carried by colour alone.
- [ ] No rainbow / jet colour map, no red-green pairing.

**Engagement**
- [ ] At least one generative prompt where the learner produces something.

**If the medium was locked to animation**
- [ ] The archetype is named (build / sweep / transformation) and not mixed.
- [ ] The final frame stands alone as a figure, and has been exported as one.
- [ ] A parameter sweep holds at named values and leaves a trace.

## Reference files

| File | Read when |
|---|---|
| `references/evidence.md` | You need the justification for a rule, are arguing a design choice with the user, or are writing up the method. Contains the findings, the numbers, and the sources. |
| `references/explainer-arc.md` | The deliverable is a video explaining a knowledge point, or an episode in a series. Read before storyboarding. |
| `references/manim.md` | Building any Manim scene. |
| `references/static-figures.md` | Building any static figure, small-multiples strip, or diagram. |
| `assets/scene_template.py` | Starting a new Manim scene. |
| `scripts/frame_check.py` | Step 5, every time. |

## Scope

Covers Manim animation and static figures. Does not build interactive widgets
and does not do voice-over production. When the gate points at an interactive,
name that and deliver the parameter sweep with a summary frame as the closest
substitute rather than silently shipping something weaker.

The gate has two modes and the difference matters: it decides the medium only
when the medium is genuinely open. When the user came for an animation, it runs
as a design spec instead. If you find yourself arguing someone out of animation
they explicitly asked for, you are running the wrong mode.
